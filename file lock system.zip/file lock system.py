# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 23:04:48 2019

@author: CITY
"""

from tkinter import *
import os
import random
import math
import sys
from random import randint
import tkinter
from tkinter import filedialog
from tkinter import messagebox
from Crypto.Util import number
 

from tkinter import *
import os
import random
import math
import sys
from random import randint
import tkinter
from tkinter import filedialog
from tkinter import messagebox
from Crypto.Util import number
 

def register():
    global register_screen
    register_screen = Toplevel(main_screen)
    register_screen.title("Register")
    register_screen.geometry("500x500") 
    global username
    global password
    global username_entry
    global password_entry
    username = StringVar()
    password = StringVar()
    Label(register_screen, text="Please enter details below", width="400", height="4", font=("Calibri", 13)).pack()
    Label(register_screen, text="").pack()
    username_lable = Label(register_screen, text="Username * ")
    username_lable.pack()
    username_entry = Entry(register_screen, textvariable=username)
    username_entry.pack()
    Label(register_screen, text="").pack()
    password_lable = Label(register_screen, text="Password * ")
    password_lable.pack()
    password_entry = Entry(register_screen, textvariable=password, show='*')
    password_entry.pack()
    Label(register_screen, text="").pack()
    Button(register_screen, text="Register", height="2", width="18", bg='brown', command = register_user).pack()

 
def login():
    global login_screen
    login_screen = Toplevel(main_screen)
    login_screen.title("Login")
    login_screen.geometry("500x500")
    Label(login_screen, text="Please enter details below", width="400", height="4", font=("Calibri", 13)).pack()
    Label(login_screen, text="").pack()
    global username_verify
    global password_verify
    username_verify = StringVar()
    password_verify = StringVar() 
    global username_login_entry
    global password_login_entry 
    Label(login_screen, text="Username * ").pack()
    username_login_entry = Entry(login_screen, textvariable=username_verify)
    username_login_entry.pack()
    Label(login_screen, text="").pack()
    Label(login_screen, text="Password * ").pack()
    password_login_entry = Entry(login_screen, textvariable=password_verify, show= '*')
    password_login_entry.pack()
    Label(login_screen, text="").pack()
    Button(login_screen, text="Login", width=18, height=2, bg='brown', command = login_verify).pack()
       
 
def register_user():
    username_info = username.get()
    password_info = password.get() 
    file = open(username_info, "w")
    file.write(username_info + "\n")
    file.write(password_info)
    file.close() 
    username_entry.delete(0, END)
    password_entry.delete(0, END)
    Label(register_screen, text="Registration Success", fg="green", font=("calibri", 11)).pack()
 


def login_verify():
    global password1
    username1 = username_verify.get()
    password1 = password_verify.get()
    username_login_entry.delete(0, END)
    password_login_entry.delete(0, END) 
    list_of_files = os.listdir()
    if username1 in list_of_files:
        file1 = open(username1, "r")
        verify = file1.read().splitlines()
        if password1 in verify:
            login_success()
        else:
            password_not_recognised()
    else:
        user_not_found()

 
def login_success():
    global login_success_screen
    login_success_screen = Toplevel(login_screen)
    login_success_screen.title("Login Successful")
    login_success_screen.geometry("500x500")
    Label(login_success_screen, text="Welcome to file Encryption",  width="400", height="2", font=("Calibri", 10)).pack()
    Label(login_success_screen, text="Please Select one Algorithm",  width="400", height="4", font=("Calibri", 13)).pack()
    Button(login_success_screen, text="Caesar cipher", width="30", height="2", bg='brown', command=cipher_code).pack()
    Label(login_success_screen, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    Button(login_success_screen, text="RSA", width="30", height="2", bg='brown', command=rsa_code).pack()
    Label(login_success_screen, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    Button(login_success_screen, text="ElGamal", width="30", height="2", bg='brown', command=elgamal_code).pack()


 
def password_not_recognised():
    global password_not_recog_screen
    password_not_recog_screen = Toplevel(login_screen)
    password_not_recog_screen.title("Failed!")
    password_not_recog_screen.geometry("500x500")
    Label(password_not_recog_screen, text="Invalid Password ",   width="400", height="4", font=("Calibri", 13)).pack()
    Button(password_not_recog_screen, text="OK", width="30", height="2", bg='brown', command=delete_password_not_recognised).pack()

 
def user_not_found():
    global user_not_found_screen
    user_not_found_screen = Toplevel(login_screen)
    user_not_found_screen.title("Failed!")
    user_not_found_screen.geometry("500x500")
    Label(user_not_found_screen, text="User Not Found",  width="400", height="4", font=("Calibri", 13)).pack()
    Button(user_not_found_screen, text="OK",  width="30", height="2", bg='brown', command=delete_user_not_found_screen).pack()
 
    
 
def delete_login_success():
    login_success_screen.destroy()
 
def delete_password_not_recognised():
    password_not_recog_screen.destroy()
 
def delete_user_not_found_screen():
    user_not_found_screen.destroy()
    
  
    
def cipher_code():
    global key
    key = 'abcdefghijklmnopqrstuvwxyz1234567890 '
    global cipher_decide
    cipher_decide = Toplevel(login_success_screen)
    cipher_decide.title("Caesar Cipher Cryptosystem")
    cipher_decide.geometry("500x500")
    Label(cipher_decide, text="Welcome",  width="400", height="2", font=("Calibri", 10)).pack()
    Label(cipher_decide, text="Please choose an option",  width="400", height="4", font=("Calibri", 13)).pack()
    Button(cipher_decide, text="Encryption", width="30", height="2", bg='brown', command=select_file_Cipher_e).pack()
    Label(cipher_decide, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    Button(cipher_decide, text="Decryption", width="30", height="2", bg='brown', command=select_file_Cipher_d).pack()
    Label(cipher_decide, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    
    
def select_file_Cipher_e():
    select_a_file= Toplevel(cipher_decide)
    select_a_file.geometry("500x500")
    select_a_file.filename = tkinter.filedialog.askopenfilename(initialdir = "/",title = "Select file")
    data = select_a_file.filename
    global f
    f = open(select_a_file.filename)
    message = f.read()
    f.close()   
    os.remove(select_a_file.filename)    
    global dkey
    dkey = 4
    global encrypted 
    encrypted = cipher_encrypt(dkey, message)    
    save_file = Toplevel(select_a_file)
    Label(save_file, text="Encrypted file where to save?", width="400", height="4", font=("Calibri", 13)).pack()
    button = Button(save_file, text="Save file as...", width="30", height="2", bg='brown', command=save_file_fnc)
    button.pack()
    save_file.geometry("500x500")   
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Encryption is Successful", width="400", height="4", font=("Calibri", 13)).pack()
   
    
    
def select_file_Cipher_d():
    select_a_file= Toplevel(main_screen)
    select_a_file.geometry("500x500")
    select_a_file.filename = tkinter.filedialog.askopenfilename(initialdir = "/",title = "Select file")
    data = select_a_file.filename
    f = open(select_a_file.filename)
    f = open(select_a_file.filename,"w")
    f.write(str(cipher_decrypt(dkey, encrypted)))
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Decryption is Successful", width="400", height="4", font=("Calibri", 13)).pack()

    
def save_file_fnc():
    f_ask = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
    if f_ask is None:
        print("not")
    f_ask.write(str(encrypted))
    f_ask.close()
   

def cipher_encrypt(n, plaintext):
    result = ''
    for l in plaintext.lower():
        try:
            i = (key.index(l) + n) % 37
            result += key[i]
        except ValueError:
            result += l
            return result.lower()
    return result

    
def cipher_decrypt(n, ciphertext):
    result = ''
    for l in ciphertext:
        try:
            i = (key.index(l) - n) % 37
            result += key[i]
        except ValueError:
            result += l
            return result.lower()                        
    return result
   
def save_file_fnc_rsa():
    f_ask = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
    if f_ask is None:
        print("not")
    f_ask.write(str(cipher2))
    f_ask.close()
   

def rsa_encrypt(pk, plaintext):   
    key, n = pk
    global cipher2
    cipher = [(ord(char) ** key) % n for char in plaintext]
    cipher2 = cipher
    return cipher

def rsa_decrypt(pk, ciphertext):
    key, n = pk
    plain = [chr((char ** key) % n) for char in ciphertext]
    return ''.join(plain)
        
    
def rsa_code():
    global rsa_decide
    rsa_decide = Toplevel(login_success_screen)
    rsa_decide.title("RSA Cryptosystem")
    rsa_decide.geometry("500x500")
    Label(rsa_decide, text="Welcome",  width="400", height="2", font=("Calibri", 10)).pack()
    Label(rsa_decide, text="Please choose an option",  width="400", height="4", font=("Calibri", 13)).pack()
    Button(rsa_decide, text="Encryption", width="30", height="2", bg='brown', command=select_file_RSA_e).pack()
    Label(rsa_decide, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    Button(rsa_decide, text="Decryption", width="30", height="2", bg='brown', command=select_file_RSA_d).pack()
    Label(rsa_decide, text="",  width="400", height="1", font=("Calibri", 13)).pack()
    
    
def select_file_RSA_e():
    def gcd(a, b):
        while b != 0:
            a, b = b, a % b
        return a

    def egcd(a, b):
        if a == 0:
            return (b, 0, 1)
        else:
            g, y, x = egcd(b % a, a)
            return (g, x - (b // a) * y, y)

    def find_d(a, m):
        g, x, y = egcd(a, m)
        if g != 1:
            raise Exception('Not exist')
        else:
            return x % m

    def rabinMiller(n):
        s = n - 1
        t = 0
        while s % 2 == 0:
            s = s // 2
            t += 1
        k = 0
        for i in range(5):
            a = random.randrange(2, n - 1)
            if v != 1:
                i = 0
                while v != (n - 1):
                    if i == t - 1:
                        return False
                    else:
                        i = i + 1
                        v = (v ** 2) % n
        return True


    def isPrime(n):
        lowPrimes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97
        , 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179
        , 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269
        , 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367
        , 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461
        , 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571
        , 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661
        , 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773
        , 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883
        , 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997]
        if (n >= 3):
            if (n & 1 != 0):
                for p in lowPrimes:
                    if (n == p):
                        return True
                    if (n % p == 0):
                        return False
                return rabinMiller(n)
        return False


    def generateLargePrime(k):
        r = 100 * (math.log(k, 2) + 1)
        r_ = r
        while r > 0:
            n = random.randrange(2 ** (k - 1), 2 ** (k))
            r -= 1
            if isPrime(n) == True:
                return n
        return "Failure after " + 'r_' + " tries."

    def generate_keypair(p, q):
        if not (generateLargePrime(8) and generateLargePrime(8)):
            raise ValueError('Both numbers must be prime.')
        elif p == q:
            raise ValueError('p and q cannot be equal')
        n = p * q
        phi = (p - 1) * (q - 1)
        e = random.randrange(1, phi)
        g = gcd(e, phi)
        while g != 1:
            e = random.randrange(1, phi)
            g = gcd(e, phi)
        d = find_d(e, phi)
        print("D : ", d)
        return ((e, n), (d, n))

    global private,public,messages
    p = generateLargePrime(4)
    q = generateLargePrime(5)
    print("Generating your public/private keypairs now . . .")
    public, private = generate_keypair(p, q)
    print("Your public key is ", public, " and your private key is ", private)
    select_a_file= Toplevel(rsa_decide)
    select_a_file.geometry("500x500")
    select_a_file.filename = tkinter.filedialog.askopenfilename(initialdir = "/",title = "Select file")
    data = select_a_file.filename
    global f_r
    f_r = open(select_a_file.filename)
    messages = f_r.read()
    f_r.close()  
    
    global encrypted_r 
    encrypted_r = rsa_encrypt(private, messages)
    f_r = open(select_a_file.filename,"w")
    f_r.write(str(encrypted_r))
    f_r.close()
    os.remove(select_a_file.filename)
    
    save_file = Toplevel(select_a_file)
    Label(save_file, text="Encrypted file where to save?", width="400", height="4", font=("Calibri", 13)).pack()
    button = Button(save_file, text="Save file as...", width="30", height="2", bg='brown', command=save_file_fnc_rsa)
    button.pack()
    save_file.geometry("500x500")
    
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Encryption is Successful",  width="400", height="4", font=("Calibri", 13)).pack()
    
def select_file_RSA_d():
    select_a_file= Toplevel(rsa_decide)
    select_a_file.geometry("500x500")
    select_a_file.filename = tkinter.filedialog.askopenfilename(initialdir = "/",title = "Select file")
    data = select_a_file.filename
    f = open(select_a_file.filename,"w")
    f.write(str(rsa_decrypt(public, encrypted_r)))
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Decryption is Successful",  width="400", height="4", font=("Calibri", 13)).pack() 


def elgamal_code():
    global elgamal_code_win
    elgamal_code_win = Toplevel(main_screen)
    elgamal_code_win.geometry("500x500")
    elgamal_code_win.title("ElGamal Cryptosystem")
    Label(elgamal_code_win,text="Select Choice", width="400", height="4", font=("Calibri", 13)).pack()
    Label(elgamal_code_win,text="").pack()
    Button(elgamal_code_win,text="Encryption", height="2", width="30", bg="brown", command=encrypt_el).pack()
    Label(elgamal_code_win,text="").pack()
    Button(elgamal_code_win,text="Decryption", height="2", width="30", bg="brown", command=decrypt_el).pack()
  
    
def selectfile_e():
    global fileselection
    fileselection=1
    Tk().withdraw()
    global filename
    filename = filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("text files",".txt"),("all files",".*"))) # show an "Open" dialog box and return the path to the selected file
    print(filename)
    global actual_name
    actual_name=os.path.basename(filename)
    filename_lable = Label(encrypt_screen, text=str(actual_name))
    filename_lable.pack()


def selectfile_e_2():
    global fileselection
    fileselection=1
    Tk().withdraw()
    global filename2
    filename2 =filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("text files",".txt"),("all files",".*"))) # show an "Open" dialog box and return the path to the selected file
    print(filename2)
    actual_name=os.path.basename(filename2)
    filename_lable = Label(decrypt_screen, text=str(actual_name))
    filename_lable.pack()


def encrypt_el():
    global encrypt_screen
    encrypt_screen = Toplevel(elgamal_code_win)
    encrypt_screen.title("Encryption")
    encrypt_screen.geometry("500x500")
    global filename,filename_saveas
    global filename_entry
    filename = StringVar()
    filename_saveas = StringVar()
    global actual_name
    actual_name=""
    Label(encrypt_screen, text="Please enter details below", width="400", height="4", font=("Calibri", 13)).pack()
    Label(encrypt_screen, text="").pack()    
    Button(encrypt_screen, text="Select File",  width="30", height="2", bg='brown', command=selectfile_e).pack()    
    filename_lable = Label(encrypt_screen, text="Type name of the encrypted file with (.txt)", width="400", height="4", font=("Calibri", 13)).pack()
    filename_entry = Entry(encrypt_screen, textvariable=filename_saveas)
    filename_entry.pack()   
    Label(encrypt_screen, text=" ", width="400", height="1", font=("Calibri", 13)).pack()
    Button(encrypt_screen, text="Encrypt", width="30", height="2", bg="brown", command=encryption_el).pack()  


def encryption_el():
    global fileselection
    if(fileselection==1):
        file = open(filename,"r")
    else:
        ck=os.path.isfile( "/"+filename.get())
        if(ck != True):
            global tmp_screen
            tmp_screen= Toplevel(main_screen)
            tmp_screen.title("No File Found")
            tmp_screen.geometry("150x100")
            Label(tmp_screen, text="File Not Exists").pack()
            return 0
        file = open("/"+filename.get(), "r")
    message = file.read()
    file.close()
    
    n_length = 512
    global p_el
    p_el = number.getPrime(n_length)
    alpha = find_primitive_root( p_el )
    global prvt_key
    prvt_key = random.randint( 1, p_el-2 )
    beta = modexp(alpha,prvt_key,p_el)
    arr=[]

    if(fileselection==1):
        os.remove(filename)
        fileselection=0
    else:
        os.remove( "/"+filename.get())
    for w in message:
        arr.append(ord(w))
        global y1,y2
        y1,y2=encrypt1(alpha,beta,arr,p_el)
        file = open("/"+filename_saveas.get(), "w")

        file.write(str(y1+y2))
        file.close()
        
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Encryption is Successful", width="400", height="4", font=("Calibri", 13)).pack()
        


def decrypt_el():
    global decrypt_screen
    decrypt_screen = Toplevel(main_screen)
    decrypt_screen.title("Decryption")
    decrypt_screen.geometry("500x500")
    global filename2,filename2_saveas
    global filename_entry
    filename2 = StringVar()
    filename2_saveas = StringVar()
    global actual_name
    actual_name=""    
    Label(decrypt_screen, text="Please enter details below", width="400", height="4", font=("Calibri", 13)).pack()
    Label(decrypt_screen, text="").pack()  
    Button(decrypt_screen, text="Select File",width="30", height="2", bg='brown', command=selectfile_e_2).pack() 
    filename_lable = Label(decrypt_screen, text="Type name of the decrypted file with (.txt)", width="400", height="4", font=("Calibri", 13)).pack()
    filename_entry = Entry(decrypt_screen, textvariable=filename2_saveas)
    filename_entry.pack()
    Label(decrypt_screen, text=" ", width="400", height="1", font=("Calibri", 13)).pack()
    Button(decrypt_screen, text="Decrypt", width="30", height="2", bg="brown", command=decryption_el).pack()


def decryption_el():
    global fileselection
    if(fileselection==1):
        file=open(filename2,"w+",encoding='utf-8')
    else:
        ck=os.path.isfile( "/"+filename2)
        if(ck != True):
            global tmp_screen
            tmp_screen= Toplevel(main_screen)
            tmp_screen.title("No File Found")
            tmp_screen.geometry("150x100")
            Label(tmp_screen, text="File Not Exists").pack()
            return 0
        file=open( "/"+filename2.get(),'r')
    file.close()
    if(fileselection==1):
        os.remove(filename2)
        fileselection=0
    else:
        os.remove( "/"+filename2.get())
    file = open( "/"+filename2_saveas.get(), "w",encoding='utf-8')
    file.write(str(decrypt1(y1,y2,prvt_key,p_el)))
    file.close()
    
    tmp_screens= Toplevel(main_screen)
    tmp_screens.title("Successful")
    tmp_screens.geometry("250x100")
    Label(tmp_screens, text="Decryption is Successful",  width="400", height="4", font=("Calibri", 13)).pack()
    
 

def decrypt1(y1,y2,prvt_key,p):
    d=[]    
    for i,j in zip(y1,y2):
        d.append((((j%p)*modexp(i,p-1-prvt_key,p))%p))    
    rslt=""   
    for i in d:
        rslt+=chr(i)
    return rslt


def find_primitive_root( p ):
		if p == 2:
				return 1
		p1 = 2
		p2 = (p-1) // p1
		while( 1 ):
				g = random.randint( 2, p-1 )
				if not (modexp( g, (p-1)//p1, p ) == 1):
						if not modexp( g, (p-1)//p2, p ) == 1:
								return g


def modexp( base, exp, modulus ):
		return pow(base, exp, modulus)


def encrypt1(alpha,beta,arr,p):
    k=random.randint(1,p-2)           
    y1=[]
    y2=[]    
    for x in arr:
        y1.append(modexp(alpha,k,p))
        y2.append(((x%p)*modexp(beta,k,p))%p)
    return y1,y2


def main_account_screen():
    global main_screen
    main_screen = Tk()
    main_screen.geometry("500x500")
    main_screen.title("Security Project")
    Label(text="Welcome", width="400", height="4", font=("Calibri", 13)).pack()
    Label(text="").pack()
    Button(text="Login", height="2", width="30", bg='brown', command = login).pack()
    Label(text="").pack()
    Button(text="Register", height="2", width="30", bg='brown', command=register).pack()
 
    main_screen.mainloop()
 
 
main_account_screen()